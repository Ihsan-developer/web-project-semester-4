<?php

namespace App\Controllers;


class UlarController extends BaseController
{


    public function ular()
    {

        return view('ular');
    }
}
