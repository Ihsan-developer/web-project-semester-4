AOS.init({
    duration: 100,
  })